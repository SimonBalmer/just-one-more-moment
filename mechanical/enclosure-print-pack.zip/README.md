# Just One More Moment — print pack

Simon Balmer · HSLU PHKI HS26

Start with [Build the device](build/README.md). Print exactly the 13 files in mechanical/stl/, one each, in millimetres at 100% scale.

The pack includes assembly drawings, wiring, stickers and a build photo. Software setup is linked to the public repository and requires internet. The optional drawing generators are in that repository.
